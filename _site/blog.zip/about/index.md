---
layout: about
---

Hello, my name is Micah Cowell. I am a self proclaimed web developer who likes the internet, hip hop, and fancy yo-yos.

# What do you do?
I make website and stuff. All the code I write is on my [Github](https://github.com/getmicah).

# What programming languages do you use?
When making websites I like using Javascript and Sass. I also like Python and making linux scripts.